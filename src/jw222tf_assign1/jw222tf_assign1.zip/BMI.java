package jw222tf_assign1;

/**
 * Created by Jorian on 1-11-2016.
 */
import java.util.Scanner;

public class BMI {
    public static void main(String[] args) {
        System.out.print("Please enter your length (m,cm): "); //There should be a error catcher to prevent error about dots instead of comma
        Scanner lengthIn = new Scanner(System.in);
        double length = lengthIn.nextDouble();
        System.out.print("Please enter your weight in kilograms: "); //Same here. if doubles were entered, round doubles to ints first.
        Scanner weightIn = new Scanner(System.in);
        int weight = weightIn.nextInt();

        int bmi = (int) Math.round(weight / (length * length));
        System.out.println("Your BMI is: " + bmi);
    }
}
