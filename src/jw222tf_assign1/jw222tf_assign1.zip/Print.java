package jw222tf_assign1;

/**
 * Created by Jorian on 1-11-2016.
 */
public class Print {
    public static void main(String[] args) {
        System.out.println("Knowledge is power!");
        System.out.println();
        System.out.println("Knowledge");
        System.out.println("is");
        System.out.println("power!");
        System.out.println();
        System.out.println("|=====================|");
        System.out.println("|                     |");
        System.out.println("| Knowledge is power! |");
        System.out.println("|                     |");
        System.out.println("|=====================|");
    }
}
